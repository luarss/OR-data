# FAQs

If you cannot find your question/answer here, please file a GitHub issue to
the appropriate repository or start a discussion.

-   Issues and bugs:
    -   OpenROAD: <https://github.com/The-OpenROAD-Project/OpenROAD/issues>
-   Discussions:
    -   OpenROAD: <https://github.com/The-OpenROAD-Project/OpenROAD/discussions>

## How can I contribute?

Thank you for your willingness to contribute. Please see the
[Getting Involved](../contrib/GettingInvolved) guide.

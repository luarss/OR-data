# New Tool

Brief description.
This tool is awesome and does a lot of things.

(Optional): provide reports, graphics, figures and other resources to better
explain how the tool works.

## Commands

### command_1

Description.

```
    command_1 [-argA] [-argB] <file>
```

-   `<file>`: Input file. This is a *Required* parameter. The parameter
    expects a `string`.
-   `-argA`: Argument A. Default value is 0. The parameter expects a `int`.
-   `-argB`: Argument B. Default value is 42. The parameter expects a `int`
    in the range [25-50].


## Example scripts

## Regression tests

## Limitations

## FAQs

Check out
[GitHub discussion](https://github.com/The-OpenROAD-Project/OpenROAD/discussions/categories/q-a?discussions_q=category%3AQ%26A+fastroute+in%3Atitle)
about this tool.

## External references (Optional)

- List papers, link to tools, etc

## Authors (Optional)

- Jane Doe.

## License

BSD 3-Clause License. See [LICENSE](LICENSE) file.

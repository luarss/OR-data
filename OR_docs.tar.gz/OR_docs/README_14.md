Si2 DEF parser 5.8-p027 with CMake support

See lefdefReadme.txt

The lef def syntax spec was downloaded from the ISPD contest area for quick reference.
http://www.ispd.cc/contests/18/lefdefref.pdf

Note ispd uses the files provided by si2 here.
http://projects.si2.org/openeda.si2.org/projects/lefdefnew/

Si2 makes it clear on their page that downloading the document does not require a license since the license for use is in the document itself.

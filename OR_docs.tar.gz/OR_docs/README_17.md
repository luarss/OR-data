Si2 LEF parser 5.8-p027 with CMake support

See lefdefReadme.txt
